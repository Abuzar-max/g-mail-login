# GOOGLE-Phishing-Page
This Phishing page is created for knowledge purpose , And You should Add the Sql data links, 
This page Created by #MKR
Page is created intend in mind that to knowledge of Phishing,
I am not responsible for Missuing this file,(Only for Students who are Learning Phishing).
If you have doubt or if you want me to teach sql to save data PING me to manoj.manina@gmail.com
Thank you
